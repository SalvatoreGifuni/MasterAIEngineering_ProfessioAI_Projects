#include <bits/stdc++.h>

using namespace std;

// Class to manage client interactions
class Interaction {
public:
    string date;
    string time;
    string location;
    optional<string> description;

    Interaction(string d, string t, string l, optional<string> desc)
        : date(d), time(t), location(l), description(desc) {}
};

// Class to manage client information
class Client {
public:
    static int nextID;
    int ID; 
    string name, surname, birthday;
    optional<string> cellNumber, email;
    vector<Interaction> appointments;
    vector<Interaction> contracts;

    // Specified Constructor
    Client(string n, string s, string b, optional<string> c, optional<string> e) : 
    ID(++nextID), name(n), surname(s), birthday(b), cellNumber(c), email(e) {}

    // Method to add an appointment
    void addAppointment(string date, string time, string location, optional<string> description) {
        appointments.push_back(Interaction(date, time, location, description));
    }  

    // Method to add a contract
    void addContract(string date, string time, string location, optional<string> description) {
        contracts.push_back(Interaction(date, time, location, description));
    }

    // Method to print interactions
    void printInteractions() const {
        if (!appointments.empty()) {
            cout << "Appointments for " << name << " " << surname << ":" << endl;
            for (const auto& appointment : appointments) {
                cout << "Date: " << appointment.date << ", Time: " << appointment.time
                     << ", Location: " << appointment.location << ", Description: " << (appointment.description ? *appointment.description : "N/A") << endl;
            }
        }

        if (!contracts.empty()) {
            cout << "Contracts for " << name << " " << surname << ":" << endl;
            for (const auto& contract : contracts) {
                cout << "Date: " << contract.date << ", Time: " << contract.time
                     << ", Location: " << contract.location << ", Description: " << (contract.description ? *contract.description : "N/A") << endl;
            }
        }
    }
};

// Class to print menus
class PrintMenu {
public:
    // Method to display main menu
    void displayMenu() {
        cout << "Choose the action:\n"
             << "1. Add Client\n"
             << "2. View All Clients\n"
             << "3. View Client\n"
             << "4. Search Client\n"
             << "5. Modify Client\n"
             << "6. Delete Client\n"
             << "7. Add Interaction\n"
             << "8. Save to CSV\n"
             << "9. Load from CSV\n"
             << "10. Exit\n"
             << "Enter your choice: " << endl;
    }

    // Method to display modify menu
    void displayModifyMenu() {
        cout << "Choose the detail to modify:\n"
             << "1. Name\n"
             << "2. Surname\n"
             << "3. Birthday\n"
             << "4. Cell Number\n"
             << "5. Email\n"
             << "6. Exit\n"
             << "Enter your choice: " << endl;
    }
};

// Class to validate inputs
class Validation {
public:

    // Helper function to validate names and surnames
    bool IsValidNameSurname(const string& variable_name_surname) {
        // Establishing a pattern for the name
        regex namePattern("^[a-zA-Z\\s.,'\\-]+$");  
        if (!regex_match(variable_name_surname, namePattern)) {
            cout << "Invalid name or surname. Only letters, spaces, and certain punctuation marks are allowed." << endl;
            return false;
        }
        return true;
    }

    // Helper function to validate cell numbers
    bool isValidCellNumber(const string& cellNumber) {
        // Establishing a pattern for the cell number
        regex cellPattern("^\\d{1,9}$");            
        if (!regex_match(cellNumber, cellPattern)) {
            cout << "Invalid cell number. Only digits allowed and length should be between 1 and 9." << endl;
            return false;
        }
        return true;
    }

    // Helper function to validate emails
    bool isValidEmail(const string& email) {
        // Establishing a pattern for the email
        regex emailPattern("^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,}$"); 
        if (!regex_match(email, emailPattern)) {
            cout << "Invalid email format." << endl;
            return false;
        }
        return true;
    }    

    // Helper function to validate dates in YYYY-MM-DD format
    bool isValidDate(const string& date) {
        // Establishing a pattern for the date
        regex datePattern("^\\d{4}-\\d{2}-\\d{2}$");     
        if (!regex_match(date, datePattern)) return false;

        // Using isstringstream to read data from a string (date)
        istringstream split_date(date);

        // Variables declaration
        int year, month, day;
        char dash1, dash2;
        
        // Value Extraction: reads the first few characters and set them to the year variable, and so on...
        split_date >> year >> dash1 >> month >> dash2 >> day;

        struct tm tm_date = {0};

        /*
        'tm_year' represents the year from 1900, so for a date such as “2023,” 'tm_year' should be set to 2023 - 1900 = 123.
        'tm_mon' represents the months from 0 (January) to 11 (December), so for a month such as “10” (October), 
        'tm_mon' should be set to 10 - 1 = 9.
        'tm_mday' represents the day of the month and can be set directly.
        */

        tm_date.tm_year = year - 1900;
        tm_date.tm_mon = month - 1;
        tm_date.tm_mday = day;

        /*
        'mktime' converts the structure 'tm' to a value 'time_t' 
        (representing time in seconds elapsed since January 1, 1970, known as Unix Epoch).
        If 'mktime' returns -1, 
        it means that the conversion failed, indicating an invalid date. In this case, the function returns false.
        */

        time_t time = mktime(&tm_date);
        if (time == -1) {
            return false;
        }

        /*
        'localtime' converts the 'time_t' value back to a 'tm' structure, using the local time zone.
        The function then compares the 'tm_year', 'tm_mon', and 'tm_mday' values of the returned 'tm' structure with the original ones. 
        If they match, the date is valid and the function returns true; otherwise, it returns false.
        */

        struct tm* tm_ptr = localtime(&time);
        return (tm_ptr->tm_year == year - 1900 && tm_ptr->tm_mon == month - 1 && tm_ptr->tm_mday == day);
    }

    // Helper function to validate time in HH:MM format
    bool isValidTime(const string& time) {
        regex timePattern("^\\d{2}:\\d{2}$");
        if (!regex_match(time, timePattern)) return false;

        // Variables declaration
        int hour, minute;

        /* Value Extraction:      
        Using the 'sscanf' function to parse the string 'time' and extract the hour and minute parts.
        'time.c_str()': Converts the string time to an array of characters '(const char*)', which is needed for 'sscanf'.
        “%d:%d": Specifies that two integers separated by a colon character are expected.
        '&hour', '&minute': The pointers to the variables where to store the extracted values.
        */

        sscanf(time.c_str(), "%d:%d", &hour, &minute);

        // Checks that 'hour' is between 0 and 23 inclusive and that 'minute' is between 0 and 59 inclusive.
        return (hour >= 0 && hour < 24 && minute >= 0 && minute < 60);
    }

    // Helper function to validate client information
    bool isValidClient(const string& name, const string& surname, const optional<string>& cellNumber, const optional<string>& email) {
        
        /*
        '!cellNumber: checks if cellNumber' is nullopt, that is, if the cell number was not supplied. 
        The ! operator negates the value of 'cellNumber'. If 'cellNumber' is nullopt, '!cellNumber' will be true.
        'isValidCellNumber(*cellNumber)': if 'cellNumber' is present (not nullopt), then it is checked for validity using the isValidCellNumber function.
        The * operator is the dereferencing operator, which extracts the value from optional. Thus, *cellNumber returns the string contained in cellNumber.
        */
       
        if (IsValidNameSurname(name) && IsValidNameSurname(surname) &&
            (!cellNumber || isValidCellNumber(*cellNumber)) &&
            (!email || isValidEmail(*email))) {
            return true;
        } else {
            return false;
        }
    }
};

// Class CRM to manage the CRM system
class CRM {
public:
    PrintMenu pm;
    Validation val;
    vector<Client> clients; // List of clients
    const string UPDATE = "Data updated successfully!";
    const string NO_FOUND = "Client not found.";

    // Method to get a valid integer
    int getValidInt() const {
        int value;
        while (true) {
            cin >> value;
            
            if (cin.fail()) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Invalid input. Please enter a valid integer: ";
            } else {
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                return value;
            }
        }
    }

    // Method to get a valid string
    string getValidString() const {
        string value;
        cin >> value;
        return value;
    }

    // Helper function to get input with validation
    string getInputWithValidation(const string& prompt, function<bool(const string&)> validator, bool optional = false) {
        string value;
        while (true) {
            cout << prompt;
            getline(cin, value);
            if (optional && value == "a") {
                return value;
            }
            if (validator(value)) {
                return value;
            } else {
                cout << "Invalid format! Please try again." << endl;
            }
        }
    }

    // Method to add a new client
    void addClient() {

        /*
        Lambda function:
        '[ captures ] ( parameters ) -> return_type { function_body }'

        Captures ([]): Specify which variables outside the lambda function are to be captured and how (by value or by reference). (&) captures all external variables.
        Parameters (()): List of function parameters, similar to the parameter list of a normal function.
        Return Type (->): (optional) Specifies the type of data that the lambda returns.
        Function body ({}): The code that is executed when the lambda is called.
        */

        string name = getInputWithValidation("Enter name: ", [&](const string& input) { return val.IsValidNameSurname(input); });
        string surname = getInputWithValidation("Enter surname: ", [&](const string& input) { return val.IsValidNameSurname(input); });
        string birth_date = getInputWithValidation("Enter birthday (YYYY-MM-DD): ", [&](const string& input) { return val.isValidDate(input); });
        string cellNumber = getInputWithValidation("Enter cell number (type 'a' to skip): ", [&](const string& input) { return val.isValidCellNumber(input); }, true);
        string email = getInputWithValidation("Enter email (type 'a' to skip): ", [&](const string& input) { return val.isValidEmail(input); }, true);

        optional<string> cellNumberOpt = cellNumber == "a" ? nullopt : optional<string>{cellNumber};
        optional<string> emailOpt = email == "a" ? nullopt : optional<string>{email};

        clients.push_back(Client(name, surname, birth_date, cellNumberOpt, emailOpt));
        cout << "Client added successfully!" << endl;
    }

    // Method to view all clients
    void viewAllClients() const {
        if (clients.empty()) {
            cout << "No clients found."  << endl;
            return;
        }

        for (const auto& client : clients) {
            cout << "ID: " << client.ID << "\nName: " << client.name << "\nSurname: " << client.surname << "\nBirthday: " << client.birthday <<  "\n--------------------------" << endl;
        }
    }

    // Method to view a client by ID
    void viewClient() const {
        cout << "Enter client ID: \n";
        int id = getValidInt();

        /*
        'find_if' allows you to find the first element in a range that satisfies a specified predicate. 
        'variable = find_if( firstCollectionElement, lastCollectionElement, condition );'
        firstCollectionElement: Where to start searching (beginning of the collection).
        lastCollectionElement: Where to stop searching (end of the collections).
        condition: A function or lambda that tells which condition must be met
        */

        auto it = find_if(clients.begin(), clients.end(), [id](const Client& client) {
            return client.ID == id;
        });
        if (it != clients.end()) {
            const Client& client = *it;
            cout << "ID: " << client.ID << "\nName: " << client.name << "\nSurname: " << client.surname << "\nBirthday: " << client.birthday
                 << "\nCell Number: " << (client.cellNumber ? *client.cellNumber : "N/A")
                 << "\nEmail: " << (client.email ? *client.email : "N/A") << endl;
            client.printInteractions();
            cout << "--------------------------" << endl;
        } else {
            cout << NO_FOUND << endl;
        }
    }

    // Method to search for a client by name or surname
    void searchClient() {
        while (true) {
            cout << "Enter '1' to search by name, '2' to search by surname or '3' to exit: \n";
            int typeToSearch = getValidInt();

            if (typeToSearch == 1 || typeToSearch == 2) {
                cout << "Enter the " << (typeToSearch == 1 ? "name" : "surname") << " to search: \n";
                string wordToSearch;
                getline(cin, wordToSearch);

                bool found = false;
                for (const auto& client : clients) {
                    if ((typeToSearch == 1 && client.name == wordToSearch) ||
                        (typeToSearch == 2 && client.surname == wordToSearch)) {
                        cout << "Client ID: " << client.ID << "\nName: " << client.name << "\nSurname: " << client.surname
                            << "\nBirthday: " << client.birthday << "\nCell Number: " << (client.cellNumber ? *client.cellNumber : "N/A")
                            << "\nEmail: " << (client.email ? *client.email : "N/A") << endl;
                        client.printInteractions();
                        cout << "--------------------------" << endl;
                        found = true;
                    }
                }
                if (!found) {
                    cout << NO_FOUND << endl;
                }
            } else if (typeToSearch == 3) {
                break;
            } else {
                cout << "Invalid search type!" << endl;
            }
        }
    }

    // Method to modify a client
    void modifyClient(int clientID) {
        auto it = find_if(clients.begin(), clients.end(), [clientID](const Client& client) {
            return client.ID == clientID;
        });
        if (it == clients.end()) {
            cout << NO_FOUND << endl;
            return;
        }

        Client& client = *it;

        // Define a map of modification options
        /*
        'Map' is an ordered collection of key-value pairs, where each unique key is associated with a value.
        Map Type: map<int, function<void()>> is a map that associates integers (int) with functions with no parameters 
        and no return type (function<void()>).
        Lambda Functions: Each value in the map is a lambda function that performs a specific modification operation on the client.
        */

        map<int, function<void()>> modificationOptions = {
            {1, [&]() { 
                string newName = getInputWithValidation("Enter new name: \n", [&](const string& input) { return val.IsValidNameSurname(input); });
                if (!newName.empty()) {
                    client.name = newName;
                    cout << UPDATE << endl;
                } else {
                    cout << "Name cannot be empty." << endl;
                }
            }},
            {2, [&]() { 
                string newSurname = getInputWithValidation("Enter new surname: \n", [&](const string& input) { return val.IsValidNameSurname(input); });
                if (!newSurname.empty()) {
                    client.surname = newSurname;
                    cout << UPDATE << endl;
                } else {
                    cout << "Surname cannot be empty." << endl;
                }
            }},
            {3, [&]() { 
                string newBirthday = getInputWithValidation("Enter new birthday (YYYY-MM-DD): \n", [&](const string& input) { return val.isValidDate(input); });
                if (!newBirthday.empty()) {
                    client.birthday = newBirthday;
                    cout << UPDATE << endl;
                } else {
                    cout << "Birthday cannot be empty." << endl;
                }
            }},
            {4, [&]() {
                string newCellNumber = getInputWithValidation("Enter new cell number or 'a' to skip: \n", [&](const string& input) { return val.isValidCellNumber(input); }, true);
                client.cellNumber = newCellNumber == "a" ? client.cellNumber : optional<string>{newCellNumber};
                cout << UPDATE << endl;
            }},
            {5, [&]() {
                string newEmail = getInputWithValidation("Enter new email or 'a' to skip: \n", [&](const string& input) { return val.isValidEmail(input); }, true);
                client.email = newEmail == "a" ? client.email : optional<string>{newEmail};
                cout << UPDATE << endl;
            }}
        };

        int choice;
        do {
            pm.displayModifyMenu();
            choice = getValidInt();

            if (modificationOptions.find(choice) != modificationOptions.end()) {
                modificationOptions[choice]();
            } else if (choice != 6) {
                cout << "Invalid choice. Please try again." << endl;
            }
        } while (choice != 6);

        cout << "Exiting modification menu..." << endl;
    }

    // Method to delete a client
    void deleteClient(int clientID) {
        auto it = find_if(clients.begin(), clients.end(), [clientID](const Client& client) {
            return client.ID == clientID;
        });
        if (it != clients.end()) {
            clients.erase(it);
            cout << "Client deleted successfully!" << endl;
        } else {
            cout << NO_FOUND << endl;
        }
    }

    // Method to add an interaction
    void addInteraction(int clientID) {
        // Find the client with the given ID
        auto it = find_if(clients.begin(), clients.end(), [clientID](const Client& client) {
            return client.ID == clientID;
        });
        if (it == clients.end()) {
            cout << NO_FOUND << endl;
            return;
        }

        Client& client = *it;
        string date, time, location, description;
        optional<string> descriptionOpt;

        // Get validated date, time, location, and description from user
        date = getInputWithValidation("Enter date (YYYY-MM-DD): ", [&](const string& input) { return val.isValidDate(input); });
        time = getInputWithValidation("Enter time (HH:MM): ", [&](const string& input) { return val.isValidTime(input); });
        location = getInputWithValidation("Enter location: ", [](const string& input) { return !input.empty(); });
        description = getInputWithValidation("Enter description (type 'a' to skip): ", [](const string& input) { return true; });
        descriptionOpt = description == "a" ? nullopt : optional<string>{description};

        // Ask the user to specify the type of interaction
        cout << "Enter interaction type ('1' for appointment or '2' for contract): ";
        int interactionType = getValidInt();

        // Add the interaction based on the specified type
        if (interactionType == 1) {
            client.addAppointment(date, time, location, descriptionOpt);
        } else if (interactionType == 2) {
            client.addContract(date, time, location, descriptionOpt);
        } else {
            cout << "Invalid interaction type!" << endl;
        }
    }

    // Method to save data to a CSV file
    void saveToCSV() const {
        try {
            ofstream file("Clients.csv");   //Open or create file on which to write
            if (!file.is_open()) {
                throw runtime_error("Error opening file for writing. Please check if you have the necessary permissions.");
            }

            file << "ID,Name,Surname,Birthday,Cell Number,Email,Appointments,Contracts" << endl;
            for (const auto& client : clients) {
                //Write client's details
                file << client.ID << "," << client.name << "," << client.surname << "," << client.birthday << ","
                    << (client.cellNumber ? *client.cellNumber : "") << ","
                    << (client.email ? *client.email : "") << ",";

                // Write appointments
                for (size_t i = 0; i < client.appointments.size(); ++i) {
                    const auto& appointment = client.appointments[i];
                    file << appointment.date << " " << appointment.time << " " << appointment.location 
                        << (appointment.description ? " " + *appointment.description : "");
                    if (i < client.appointments.size() - 1) {
                        file << ";";
                    }
                }

                file << ",";

                // Write contracts
                for (size_t i = 0; i < client.contracts.size(); ++i) {
                    const auto& contract = client.contracts[i];
                    file << contract.date << " " << contract.time << " " << contract.location 
                        << (contract.description ? " " + *contract.description : "");
                    if (i < client.contracts.size() - 1) {
                        file << ";";
                    }
                }

                file << endl;
            }

            file.close();
            cout << "Data saved successfully." << endl;
        } catch (const exception& e) {
            cerr << "An error occurred: " << e.what() << endl;
        }
    }

    // Helper function to parse interactions
    void parseInteractions(const string& data, vector<Interaction>& interactions) {
        istringstream totInteraction(data);
        string ElementInteraction;

        while (getline(totInteraction, ElementInteraction, ';')) {
            istringstream OneElement(ElementInteraction);
            string date, time, location, description;
            getline(OneElement, date, ' ');
            getline(OneElement, time, ' ');
            getline(OneElement, location, ' ');
            getline(OneElement, description);
            interactions.push_back(Interaction(date, time, location, description.empty() ? nullopt : optional<string>{description}));
        }
    }

    // Method to load data from a CSV file
    void loadFromCSV() {
        try {
            ifstream file("Clients.csv");   //Open the file from which to read
            if (!file.is_open()) {
                throw runtime_error("Error opening file for reading. Please check if the file exists and you have the necessary permissions.");
            }

            clients.clear();
            string line;
            getline(file, line); // Skip header line

            while (getline(file, line)) {
                istringstream totLine(line);
                string idStr, name, surname, birthDate, cellNumber, email, appointmentsStr, contractsStr;
                int id;

                // Extract data for each client
                getline(totLine, idStr, ',');
                id = stoi(idStr);   //Convert the string into an int
                getline(totLine, name, ',');
                getline(totLine, surname, ',');
                getline(totLine, birthDate, ',');
                getline(totLine, cellNumber, ',');
                getline(totLine, email, ',');
                getline(totLine, appointmentsStr, ',');
                getline(totLine, contractsStr, ',');

                optional<string> cellNumberOpt = cellNumber.empty() ? nullopt : optional<string>{cellNumber};
                optional<string> emailOpt = email.empty() ? nullopt : optional<string>{email};

                Client client(name, surname, birthDate, cellNumberOpt, emailOpt);
                client.ID = id;

                // Parse appointments and contracts
                parseInteractions(appointmentsStr, client.appointments);
                parseInteractions(contractsStr, client.contracts);

                clients.push_back(client);

                // Update the nextID if necessary
                if (id > Client::nextID) {
                    Client::nextID = id;
                }
            }

            file.close();
            cout << "Data loaded successfully." << endl;
        } catch (const ifstream::failure& e) {
            cerr << "An error occurred while reading the file: " << e.what() << endl;
        } catch (const invalid_argument& e) {
            cerr << "Invalid data format in CSV file: " << e.what() << endl;
        } catch (const exception& e) {
            cerr << "An error occurred: " << e.what() << endl;
        }
    }
};

// Initialize static client ID counter
int Client::nextID = 0;

// Main function
int main() {
    CRM crm;
    int choice;
    do {
        crm.pm.displayMenu();
        choice = crm.getValidInt();
        switch (choice) {
            case 1:
                crm.addClient();
                break;
            case 2:
                crm.viewAllClients();
                break;
            case 3:
                crm.viewClient();
                break;
            case 4:
                crm.searchClient();
                break;
            case 5: {
                cout << "Enter client ID to modify: ";
                int clientID = crm.getValidInt();
                crm.modifyClient(clientID);
                break;
            }
            case 6: {
                cout << "Enter client ID to delete: ";
                int clientID = crm.getValidInt();
                crm.deleteClient(clientID);
                break;
            }
            case 7: {
                cout << "Enter client ID to add interaction: ";
                int clientID = crm.getValidInt();
                crm.addInteraction(clientID);
                break;
            }
            case 8:
                crm.saveToCSV();
                break;
            case 9:
                crm.loadFromCSV();
                break;
            case 10:
                cout << "Exiting..." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }
    } while (choice != 10);

    return 0;
}
